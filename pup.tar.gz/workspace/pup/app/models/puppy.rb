class Puppy < ActiveRecord::Base
end
