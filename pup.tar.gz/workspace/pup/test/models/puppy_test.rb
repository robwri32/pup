require 'test_helper'

class PuppyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
